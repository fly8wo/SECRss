function NSLog(str) {
    window.webkit.messageHandlers.nslog.postMessage(str);
}


function render(block) {
    if (document.hidden) {
        setTimeout(block,1000/120);
    }
    else {
        var requestId = -1
        requestId = requestAnimationFrame(function() {
            requestId = -1
            block()
        });
        setTimeout(function() {
            if (requestId > -1) {
                cancelAnimationFrame(requestId)
                block()
            }
        },1000/30);
    }
}

function didRender() {
    render(function() {
        window.webkit.messageHandlers.didRender.postMessage(true);
    });
}





var reeder = {
    
    ping: function() {
        return "true";
    },
    
    lastScroll: 0,
    
    init: function() {
        
        reeder.macos = reeder.os('macos');
        reeder.ios = reeder.os('ios');
        
        reeder.articleNode = document.querySelector('body > main > article');

        var iframe = document.createElement('iframe');
        iframe.srcdoc = '<html><head><body onresize="window.parent.reeder.didLayout()"></body></html>';
        document.querySelector('body > main').appendChild(iframe);

        
        if (reeder.macos) {
            window.onresize = function() {
                reeder.didLayout()
            }
        }
        
        if (reeder.ios) {
            window.onscroll = function(e) {
                reeder.lastScroll = Date.now()
            }
            window.onkeydown = function(e) {
                if (!e.altKey && !e.ctrlKey && !e.metaKey) {
                    if (!e.shiftKey) {
                        if (e.code == 'ArrowLeft' || e.code == 'ArrowRight' || e.code == 'ArrowUp' || e.code == 'ArrowDown' || e.code == 'Space') {
                            window.webkit.messageHandlers.keyDown.postMessage(e.code);
                            return false
                        }
                    }
                    else if (e.code == 'Space') {
                        window.webkit.messageHandlers.keyDown.postMessage('Shift'+e.code);
                    }
                }
                return true
            }
        }
        
    },
    
	
    platform: '[PLATFORM]',
    platformNativeContextMenu: [PLATFORM_NATIVE_CONTEXT_MENU],
    
    os: function(platform) {
        return (this.platform == platform);
    },

    macos: false,
    ios: false,
    
    articleContent: {},
    readerMode: false,

    itemId: "",
    
    set: function(data) {
        this.itemId = data["id"];
        this.readerMode = false;
        this.articleContent = data;//data["html"];
        var link = data["link"];
        document.querySelector("head > base").setAttribute("href",link);
        this.load(data);
    },
    

    reload: function(data) {
        this.load({"html":this.html, "titleHeight": document.querySelector('body > main > article > header').style.height})
    },
    
    html: "",
    load: function(data) {
        
        try {

            if (this.macos) {
                window.scroll(0,0)
            }
            document.querySelector('body > main > article > header').style.height = data["titleHeight"];

            var article = document.querySelector('body > main > article');
            

            reeder.clear();
            this.html = data["html"];
            
            if (data["enteringReader"] == "true") {
                var loading = document.createElement('div');
                loading.setAttribute('class','reeder-reader-loading');
                loading.innerHTML = "<span></span><span></span><span></span><span></span>";
                document.body.appendChild(loading)
            }

            var div = document.createElement('div');
            div.innerHTML = data['html'];
            reeder.prepare(div);
            article.appendChild(div);
            
            if (this.itemId == "") {
                document.querySelector('body > div').style.display = 'block';
            }
            else {
                
                document.querySelector('body > div').style.display = 'none';

                if (reeder.isBionicActive) {
                    reeder.setBionic(true)
                }
            
                if (div.querySelectorAll('blockquote.twitter-tweet').length > 0) {
                    var script = document.createElement('script');
                    script.onload = function() {
                        twttr.widgets.load();
                    }
                    script.src = "https://platform.twitter.com/widgets.js";
                    div.appendChild(script);
                }
                
                if (div.querySelectorAll('blockquote.instagram-media').length > 0) {
                    var script = document.createElement('script');
                    script.onload = function() {
                        instgrm.Embeds.process();
                    }
                    script.src = "https://www.instagram.com/embed.js";
                    div.appendChild(script);
                }
                
                if (div.querySelectorAll('p.codepen').length > 0) {
                    var script = document.createElement('script');
                    script.onload = function() {
                        //instgrm.Embeds.process();
                    }
                    script.src = "https://static.codepen.io/assets/embed/ei.js";
                    div.appendChild(script);
                }
            }

            this.forceRefresh()
            
        }
        catch {
        }
        finally {
        }

        render(function() {
            didRender()
        })

    },

    
    
    clear: function() {
        
        this.html = ""
        
        window.getSelection().removeAllRanges();
        
        reeder.imagesByRef = {}
        
        reeder.paused = false
        
        document.querySelectorAll('html > head > script').forEach(function(node) {
            node.parentNode.removeChild(node);
        });
        
        document.querySelectorAll('body > main > article > div').forEach(function(div) {

            div.querySelectorAll('img').forEach(function(img) {
                img.removeAttribute('src')
                img.removeAttribute('srcset')
                img.parentNode.removeChild(img);
            })
            
            div.querySelectorAll("audio,video").forEach(function(node) {
                node.src = null;
                node.load();
                node.parentNode.removeChild(node);
            });

            div.querySelectorAll("iframe").forEach(function(node) {
                node.removeAttribute("src");
                node.parentNode.removeChild(node);
            })
            
            div.parentNode.removeChild(div);
            
        });
        
        
        
        document.querySelectorAll('body > div.reeder-reader-loading').forEach(function(div) {
            div.parentNode.removeChild(div);
        });

        
    },
    
    paused: false,
    pause: function() {
        document.querySelectorAll('audio, video').forEach(function(media) {
            media.pause();
        });
        
        if (reeder.macos) {
            document.querySelectorAll('body > main > article iframe').forEach(function(frame) {
                frame.dataset.src = frame.src;
                frame.removeAttribute("src");
                reeder.paused = true
            });
        }
    },
    

    resume: function() {
        if (!reeder.paused) {
            return
        }
        document.querySelectorAll('body > main > article iframe').forEach(function(frame) {
            frame.src = frame.dataset.src
        });
        reeder.paused = false
    },
    
    enterReader: function(contentDict) {
        this.readerMode = true;
        this.load(contentDict);
    },
    
    exitReader: function() {
        this.readerMode = false;
        //this.load({"html":this.articleContent});
        this.load(this.articleContent)
    },
    

    setTitleHeight: function(value) {
        render(function() {
            document.querySelector('body > main > article > header').style.height = value + 'px';
        })
    },
    
    forceRefresh: function() {
        document.body.style.transform = 'translateZ(0)';
        render(function() {
            document.body.style.transform = 'none';
        })
    },
    
    setVar: function(key, value) {
        document.documentElement.style.setProperty(key, value);
        //this.forceRefresh();
    },
    getVar: function(key) {
        return document.documentElement.style.getPropertyValue(key);
    },
    
    
    imageDidLoad: function(image) {
                
        render(function() {
            var width = image.naturalWidth + 'px';
            var nodeWidth = "min(var(--media-max-width), "+ width +")";
            
            if (window.getComputedStyle(image, null).getPropertyValue('direction') == 'rtl') {
                image.style.right = "calc(min(0px, 50% - 0.5 * " + nodeWidth + "))";
            }
            else {
                image.style.left = "calc(min(0px, 50% - 0.5 * " + nodeWidth + "))";
            }
            image.style.width = "calc(" + nodeWidth + ")";
            image.style.borderRadius =  "calc(min(1px, (100vw - " + nodeWidth + ")) * 3)";
            
            
            if (image.parentNode.childNodes[0] == image) {
                image.style.display = 'block';
            }
        });
        
    },
    
    
    imagesByRef: {}, // [Int:Image]
    imageRef: 0,
    didTapOnImage: function(img) {
        
        if (reeder.macos && img.dataset.link == "true") {
            return
        }
        
        this.viewImage(img)

    },
    
    contextImageAt: function(x,y) {
        var img = document.elementFromPoint(x,y)
        if (img == null) {
            return
        }
        if (img.tagName == 'IMG') {
            this.viewImage(img)
        }
    },
    
    didContextOnImage: function(img) {
        

        this.imageRef += 1;
        this.imagesByRef[this.imageRef] = img;
                
        var info = {
            "image": img.tagName == 'VIDEO' ? img.poster : img.currentSrc,
            "ref": this.imageRef
        }
        
        if (img.tagName == 'VIDEO') {
            info["video"] = img.currentSrc
        }
        else if (img.hasAttribute("data-video")) {
            info["video"] = img.dataset.video
        }
        
        
//        NSLog("ctx")
//        NSLog(info["image"])
//        NSLog(info["ref"])
//        NSLog(info["video"])

    
        window.webkit.messageHandlers.contextImageRef.postMessage(info)

    },
    
    viewContextImage: function(ref) {
        var img = this.imagesByRef[ref]
        if (img == null) {
            return
        }
        this.viewImage(img)
    },
    
    imgViewerAlpha: function() {
        if (this.macos) {
            return 0.03
        }
        else {
            return 0.01
        }
    },
    
    viewImage: function(img) {
        
        if (img.style.opacity == this.imgViewerAlpha()) {
            return
        }
        
        var r = img.getBoundingClientRect();
        this.imageRef += 1;
        this.imagesByRef[this.imageRef] = img;
        
        var link = ''
        if (img.dataset.href != null) {
            link = img.dataset.href
        }
        
        var alt = ''
        if (img.hasAttribute('alt')) {
            alt = img.getAttribute('alt');
        }
        var title = ''
        if (img.hasAttribute('title')) {
            alt = img.getAttribute('title');
        }

        window.webkit.messageHandlers.imgTap.postMessage({
            "ref": this.imageRef,
            "image": img.tagName == 'VIDEO' ? img.poster : img.currentSrc,
            "x": r.x,
            "y": r.y,
            "width": r.width,
            "height": r.height,
            "link": link,
            "alt": alt,
            "title": title
        });
    },
    
    
    didLongPressOnImage: function(img) {
        
        if (img.style.opacity == this.imgViewerAlpha()) {
            return
        }
        
        
        var r = img.getBoundingClientRect();
        this.imageRef += 1;
        this.imagesByRef[this.imageRef] = img;
        
        var link = ''
        if (img.dataset.href != null) {
            link = img.dataset.href
        }
        
        var alt = ''
        if (img.hasAttribute('alt')) {
            alt = img.getAttribute('alt');
        }
        var title = ''
        if (img.hasAttribute('title')) {
            alt = img.getAttribute('title');
        }
        
        window.webkit.messageHandlers.imgTapAndHold.postMessage({
            "ref": this.imageRef,
            "image": img.tagName == 'VIDEO' ? img.poster : img.currentSrc,
            "x": r.x,
            "y": r.y,
            "width": r.width,
            "height": r.height,
            "link": link,
            "alt": alt,
            "title": title
        });
    },

    
    setImageHidden: function(hidden, ref) {
        var img = this.imagesByRef[ref]
        if (img == null) {
            didRender()
            return
        }
        
        if (hidden) {
            img.style.opacity = this.imgViewerAlpha()
            didRender()
        }
        else {
            render(function() {
                img.style.opacity = 1.0;
                didRender()
            })
        }
        
    },

    
//    setImageHidden: function(hidden, ref) {
//        var img = this.imagesByRef[ref]
//        if (img == null) {
//            return
//        }
//
//        img.style.opacity = hidden ? this.imgViewerAlpha() : 1.0;
////        if (this.macos) {
////            if (hidden) {
////                render(function() {
////                    img.style.filter = "grayscale(100%)"
////                })
////            }
////            else {
////                img.style.filter = "none"
////            }
////        }
//
//        didRender()
//    },
    
    rectForImage: function(ref) {
        var img = this.imagesByRef[ref]
        if (img == null) {
            return {}
        }
        var r = img.getBoundingClientRect();
        return {
            "x": r.x,
            "y": r.y,
            "width": r.width,
            "height": r.height
        }
    },
    
    prepare: function(div) {
        
                        
        {
            var codes = div.querySelectorAll('code');
            codes.forEach(function(code) {
                if (code.parentNode.tagName == 'PRE') {
                    code.parentNode.dataset.code = "true";
                }
            });
            
            var links = div.querySelectorAll('a');
            links.forEach(function(link) {
                var imgs = link.querySelectorAll('img');
                if (imgs.length == 0) {
                    link.dataset.image = "false";
                }
                else {
                    imgs.forEach(function(i) {
                        i.dataset.link = "true"
                        i.dataset.href = link.href
                    });

                    link.dataset.image = "true";
                    
                    if (reeder.ios) {
                        link.onclick = function() {
                            return false
                        }
                    }
                }
            })
            
        }
        
        // Lists
        {
            div.querySelectorAll("ul, ol").forEach(function(list) {
                var isGallery = true
                list.querySelectorAll("li").forEach(function(li) {
                    if (li.querySelectorAll("img").length == 0) {
                        isGallery = false
                    }
//                    else if (li.querySelectorAll("img.latex, img.wp-smiley").length > 0) {
//                        isGallery = false
//                    }
                })
                if (isGallery) {
                    list.dataset.gallery = "true"
                }
            })
        }
        
        // Tables
        {
            div.querySelectorAll("tr").forEach(function(tr) {
                tr.setAttribute('valign','top')
            })
        }

        { // Images
            
            var nodes = div.querySelectorAll('img');
            
            nodes.forEach(function(img) {
                
                img.removeAttribute('width');
                img.removeAttribute('height');
                img.removeAttribute('style');
                img.removeAttribute('hspace');
                

                if ((img.width == 1 && img.height == 1) || (img.style.width == '1px' && img.style.height == '1px')) {
                    img.parentNode.removeChild(img);
                    return
                }
                
                if (img.complete) {
                    reeder.imageDidLoad(img);
                }
                else {
                    img.onload = function() {
                        reeder.imageDidLoad(this);
                    }
                }
                
                
                if (reeder.ios) {
                    var cancelled = false;
                    var longpress = false;

                    var timer = null;
                    
                    img.oncontextmenu = function() {
                        reeder.didLongPressOnImage(img)
                    }
                    
                    
                    img.onclick = function() {
                        reeder.didTapOnImage(img)
                    }
                    
                    var touchX = 0
                    var touchY = 0
                    img.ontouchstart = function(e) {
                        if (e.touches.length != 1) {
                            cancelled = true;
                            return
                        }

                        var dt = Date.now() - reeder.lastScroll
                        if (dt < 50) {
                            cancelled = true;
                            return;
                        }
                        
                        touchX = e.touches.item(0).screenX;
                        touchY = e.touches.item(0).screenY;

                        
                        clearTimeout(timer)
                        timer = setTimeout(function() {
                            if (cancelled) {
                                return
                            }
                            cancelled = true
                            longpress = true
                            
                            document.body.dataset.selectable = 'false';
                            
                            reeder.didLongPressOnImage(img)
                        },300)
                        cancelled = false;
                        longpress = false;
                    }
                    img.ontouchmove = function(e) {
                        if (e.touches.length == 1) {
                            if (Math.abs(e.touches.item(0).screenX - touchX) <= 10 && Math.abs(e.touches.item(0).screenY - touchY) <= 10) {
                                return
                            }
                        }

                        cancelled = true;
                        clearTimeout(timer)
                    }
                    img.ontouchcancel = function() {
                        cancelled = true;
                        clearTimeout(timer)
                        if (longpress) {
                            longpress = false;
                            setTimeout(function() {
                                if (cancelled) {
                                    window.getSelection().removeAllRanges();
                                    document.body.dataset.selectable = 'true';
                                }
                            },100)
                        }
                    }
                    img.ontouchend = function() {
                        var fire = !cancelled
                        cancelled = true
                        clearTimeout(timer)
                        if (fire) {
                            reeder.didTapOnImage(img)
                        }
                        
                        
                        if (longpress) {
                            longpress = false
                            setTimeout(function() {
                                if (cancelled) {
                                    window.getSelection().removeAllRanges();
                                    document.body.dataset.selectable = 'true';
                                }
                            },100)
                        }
                    }
                }
                else {
                    
                    img.oncontextmenu = function() {
                        reeder.didContextOnImage(img)
                    }
                    
                    img.onclick = function() {
                        reeder.didTapOnImage(img)
                    }
                }
            });
        }
        
        { // Videos
            
            var nodes = div.querySelectorAll('video');
                        
            nodes.forEach(function(vid) {
                
                vid.controls = true;
                vid.setAttribute("playsinline","true");
                vid.autoplay = false;
                vid.muted = false;
                
                
                vid.removeAttribute('style');
                vid.removeAttribute('width');
                vid.removeAttribute('height');
                

                var hastPoster = false
                var posterImage = -1
                if (vid.hasAttribute("poster")) {
                    hasPoster = true
                    var img = vid.poster;
                    if (img.startsWith('http:') || img.startsWith('https:')) {
                        vid.poster = 'reeder-' + img;
                        posterImage = 'reeder-' + img;
                    }
                }
                                
                
                var styleLeft = "calc(min(0px, 50% - 0.5 * min(var(--media-max-width),var(--def-max-content-width))))";
                var styleWidth = "min(var(--media-max-width),var(--def-max-content-width))";
                var borderRadius =  "calc(min(1px, (100vw - " + styleWidth + ")) * 3)";

                
                
                
                render(function() {
                    vid.style.left = styleLeft;
                    vid.style.width = styleWidth;
                    vid.style.borderRadius = borderRadius;

                });
                
                if (posterImage != -1) {
                    var div = document.createElement('div');
                    div.setAttribute('class', 'reeder-video-wrapper');
                    div.innerHTML = '<img src="' + posterImage + '" style="left:' + styleLeft + '; width: ' + styleWidth + '; border-radius: ' + borderRadius + '" /><div><div></div></div>';
                    
                    var img = div.children[0]

                    vid.parentNode.insertBefore(div, vid);
                    //vid.parentNode.removeChild(vid)
                    vid.style.display = 'none';
                    vid.preload = "metadata"
                                        
                    if (reeder.ios) {
                        var load = false;
                        div.ontouchstart = function() {
                            load = true;
                        }
                        div.ontouchmove = function() {
                            load = false;
                        }
                        div.ontouchend = function() {
                            if (load) {
                                didLoad = true
                                setTimeout(function() {
                                    vid.style.display = 'block';
                                    vid.play();
                                    vid.controls = false
                                    div.parentNode.removeChild(div);
                                },100)
                                vid.ontouchstart = function() {
                                    vid.controls = true;
                                    vid.ontouchstart = null;
                                    vid.onclick = null;
                                }
                                vid.onclick = function() {
                                    vid.controls = true;
                                    vid.ontouchstart = null;
                                    vid.onclick = null;
                                }
                            }
                        }
                    }
                    
                    div.onclick = function() {
                        didLoad = true
                        vid.controls = true
                        vid.preload = "auto"
                        setTimeout(function() {
                            vid.style.display = 'block';
                            vid.play();
                            div.parentNode.removeChild(div);
                        },100)
                                                
                    }

                    if (reeder.macos) {
                        img.oncontextmenu = function() {
                            if (vid.currentSrc != "") {
                                img.dataset.video = vid.currentSrc
                            }
                            reeder.didContextOnImage(img)
                        }
                    }
                    
                }
                
                if (reeder.ios) {
                    vid.ontouchstart = function() {
                        vid.controls = true;
                        vid.ontouchstart = null;
                        vid.onclick = null;
                    }
                    vid.onclick = function() {
                        vid.controls = true;
                        vid.ontouchstart = null;
                        vid.onclick = null;
                    }
                }
                
                if (reeder.macos) {
                    vid.onmouseover = function() {
                        vid.controls = true;
                    }
                    vid.onmouseout = function() {
                        if (vid.currentTime > 0 && !vid.paused && !vid.ended && vid.readyState > 2) {
                            vid.controls = false;
                        }
                    }
                                        
                    vid.oncontextmenu = function() {
                        reeder.didContextOnImage(vid)
                    }
                }
                
                
            });
        }
        
        
        { // Other elements
            var nodes = div.querySelectorAll('iframe,object,embed');
            nodes.forEach(function(node) {
                
//                var width = parseInt(node.style.width)
//                var height = parseInt(node.style.height)
//
//                if (node.hasAttribute('width')) {
//                    width = parseInt(node.width)
//                }
//                if (node.hasAttribute('height')) {
//                    height = parseInt(node.height)
//                }
                
                var width = node.style.width || node.width || "100%"
                var height = node.style.width || node.height || "100%"
                
                if (width.endsWith('%') || height.endsWith('%')) {
                    width = 1600
                    height = 900
                }
                else {
                    width = parseInt(width)
                    height = parseInt(height)
                }
                
                
                
                                
                node.removeAttribute('width');
                node.removeAttribute('height');
                node.removeAttribute('style');

                var aspect = width / height;
                var nodeWidth = "min(var(--media-max-width), " + width + "px)";

                node.style.width = "calc(" + nodeWidth + ")"
                node.style.left =  "calc(min(0px, 50% - 0.5 * " + nodeWidth + "))";
                node.style.height = "calc(min(var(--media-max-width), " + width + "px) / " + aspect + ")";
                node.style.borderRadius =  "calc(min(1px, (100vw - " + nodeWidth + ")) * 3)";
                
                if (node.tagName == 'IFRAME') {
                    node.setAttribute("scrolling","no");
                }
                
                
//                if (node.tagName == "IFRAME" && reeder.ios) {
//                    node.dataset.src = node.src;
//                    node.removeAttribute("src");
//                    var clr = reeder.getVar('--pre-background-color');
//                    node.srcdoc = "<html style=\"height:100%\"><body style=\"height:100%; margin: 0; padding: 0;></body></html>"
//                    node.onload = function() {
//                        var load = false;
//                        node.contentWindow.ontouchstart = function() {
//                            load = true;
//                        }
//                        node.contentWindow.ontouchmove = function() {
//                            load = false;
//                        }
//                        node.contentWindow.ontouchend = function() {
//                            if (load) {
//                                node.removeAttribute('srcdoc');
//                                node.src = node.dataset.src;
//                                node.contentWindow.onclick = null;
//                            }
//                        }
//                    }
//                }
            });
        }
        
    },

    
    
    rectInfo: function() {
        return {
            "x": window.scrollX,
            "y": window.scrollY,
            "width": document.documentElement.clientWidth,

            //catalina "documentHeight": document.documentElement.scrollHeight
            //"documentHeight": document.body.scrollHeight
            "documentHeight": Math.min(document.body.scrollHeight,document.documentElement.scrollHeight)
        }
    },
    
    postDidLayout: false,
    didLayout: function() {
        reeder.postDidLayout = true;
        render(function() {
            reeder.postDidLayoutIfNeeded();
        });
    },
    
    postDidLayoutIfNeeded: function() {
        if (!reeder.postDidLayout) {
            return;
        }
        reeder.postDidLayout = false;
        window.webkit.messageHandlers.layout.postMessage(this.rectInfo())
    },
    
    didReloadStyle: function() {
        render(function() {
            var info = reeder.rectInfo()
            info["reload"] = true
            window.webkit.messageHandlers.layout.postMessage(info)
        })
    },
    
    
    
    
    // Feed search
    feeds: function(dict) {
        var html = dict["html"];
        var url = dict["url"];
        
        
        var parser = new DOMParser();
        var docXml = parser.parseFromString(html, "text/xml");
        var docHtml = parser.parseFromString(html, "text/html");

        
        var feeds = []

        var rssXml = docXml.querySelectorAll('channel > title');
        var rssHtml = docHtml.querySelectorAll('channel > title');
        var atomXml = docXml.querySelectorAll('feed > title');
        var atomHtml = docHtml.querySelectorAll('feed > title');
                
        var node = null
        var linkNodes = []
        var linkSelector = ''
        if (rssXml.length > 0) {
            node = rssXml[0]
            linkNodes = docXml.querySelectorAll('channel > link')
        }
        else if (rssHtml.length > 0) {
            node = rssHtml[0]
            linkNodes = docHtml.querySelectorAll('channel > link')
        }
        else if (atomXml.length > 0) {
            node = atomXml[0]
            linkNodes = docXml.querySelectorAll('feed > link')
        }
        else if (atomHtml.length > 0) {
            node = atomHtml[0]
            linkNodes = docHtml.querySelectorAll('feed > link')
        }


        if (node != null) {
            var link = ""
            if (linkNodes.length > 0) {
                var linkNode = linkNodes[0]
                if (linkNode.tagName.toLowerCase() != 'link' && linkNodes.length > 1) {
                    linkNode = linkNodes[1]
                }
                if (linkNode.hasAttribute("href")) {
                    link = linkNode.getAttribute("href")
                }
                else {
                    link = linkNode.textContent
                }
            }
            
            feeds.push({
                "title": node.textContent,
                "href": url,
                "type": "rss",
                "link": link
            })
        }
        else {
            
            var doc = docHtml

            var base = doc.createElement('base')
            base.href = url
            doc.querySelector("head").appendChild(base);
            
            

            doc.querySelectorAll('link').forEach(function(link) {
                if (link.hasAttribute("rel") && link.getAttribute("rel").toLowerCase() == "alternate" && link.hasAttribute("href")) {
                    var title = ""
                    if (link.hasAttribute("title")) {
                        title = link.title
                    }
                    var type = ""
                    if (link.hasAttribute("type")) {
                        type = link.type.toLowerCase()
                    }

                    var href = link.href
                    feeds.push({
                        "title": title,
                        "href": href,
                        "type": type,
                        "link": url
                    })
                    
                }
            })
        }
        
        
        
    
        return feeds
        
    },
    
        
    readerImages: function(doc) {
        var nodes = doc.querySelectorAll('img');
        nodes.forEach(function(img) {
            if (img.dataset.src != null) {
                img.src = img.dataset.src
            }
            if (img.dataset.srcset != null) {
                img.srcset = img.dataset.srcset
            }
            if (img.dataset.lazySrc != null) {
                img.src = img.dataset.lazySrc
            }
            if (img.dataset.lazySrcSet != null) {
                img.srcset = img.dataset.lazySrcSet
            }
            
            if (img.hasAttribute("alt")) {
                var alt = img.getAttribute("alt")
//                var temp = document.createElement("div");
//                temp.innerHTML = alt;
//                img.setAttribute("alt", temp.textContent || temp.innerText || "");
                img.setAttribute("alt", alt.replace(/(<([^>]+)>)/ig,""));
            }
            
            if (img.src == "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7") {
                img.parentNode.removeChild(img);
            }
            else if (img.src == "data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==") {
                img.parentNode.removeChild(img);
            }
        });
        
    },
    
//    readerGalleries: function(doc) {
//        var nodes = doc.querySelectorAll('*[data-src]');
//        nodes.forEach(function(node) {
//
//            if (node.tagName == 'IMG') {
//                return
//            }
//
//            if (node.querySelector('img') != null) {
//                return
//            }
//
//            var src = node.dataset.src;
//            var srcset = node.dataset.srcset;
//            if (srcset == null) {
//                srcset = node.dataset.responsive;
//            }
//
//            if (src == null || srcset == null) {
//                return
//            }
//
//            if ((src.startsWith("http://") || src.startsWith("https://")) && (srcset.startsWith("http://") || srcset.startsWith("https://"))) {
//                var img = document.createElement('img');
//                img.src = src;
//                img.srcset = srcset;
//                node.insertBefore(img,node.childNodes[0]);
//            }
//
//        });
//    },
    
    readerImageObjects: function(doc) {
        if (doc.querySelectorAll('img').length > 0) {
            return
        }
        
        var nodes = doc.querySelectorAll("*[itemtype$='://schema.org/ImageObject']");
        nodes.forEach(function(node) {

            if (node.querySelectorAll("img").length > 0) {
                return
            }
            
            var src = null;
            
            var meta = node.querySelector("*[itemprop='url']");
            if (meta != null) {
                src = meta.getAttribute("content");
            }
            
            if (src == null) {
                src = node.getAttribute("itemid");
            }
            
            if (src != null && (src.startsWith("http://") || src.startsWith("https://"))) {
                var img = document.createElement("img");
                img.src = "reeder-" + src;
                node.insertBefore(img,node.childNodes[0]);
            }
            
        });
    }


}


reeder.init();







//BIONIC

//brf
//reeder.bionicFixation = 3;
//reeder.bionicSaccade = 10;
//reeder.bionic = function() {
    
    //brf
    //var article = document.querySelector('body > main > article > div')
    //var br = new BionicReader(reeder.bionicFixation, reeder.bionicSaccade)
    //br.renderNode(article)
    //article.dataset.bionic = "true"
//    reeder.setBionic(true)
    
//}

reeder.bionicPreview = function(text) {
    var div = document.createElement('div')
    div.innerHTML = text
    
    //brf
    //var br = new BionicReader(reeder.bionicFixation, reeder.bionicSaccade)
    var br = new BionicReader(BionicReader.settings.fixation, BionicReader.settings.saccade);
    
    br.renderNode(div)
    var html = ""
    div.childNodes[0].childNodes.forEach(function(node) {
        if (node.nodeType == Node.TEXT_NODE) {
            html += node.nodeValue
        }
        else if (node.nodeType == Node.ELEMENT_NODE) {
            html += "<b>" + node.innerHTML + "</b>"
        }
    })
    return html
}

reeder.isBionicActive = false


reeder.setBionic = function(on) {
    
//    if (on == reeder.isBionicActive) {
//        return
//    }
    
    //brf
    reeder.isBionicActive = on
    document.querySelector('body > main > article > div').dataset.bionic = on ? "true" : "false"
    if (on) {
        BionicReader.apply('body > main > article > div');
    }
    else {
        BionicReader.clear()
    }
}
reeder.toggleBionic = function() {
    //brf
    reeder.setBionic(!reeder.isBionicActive)
}
