(function() {
 
     if (window.top != window.self) {
         return
     }
 
    document.addEventListener("DOMContentLoaded", function(event) {
    
    
        done = true
        var links = document.querySelectorAll('link');
        var found = "false";
        for (const link of links) {
            if (link.hasAttribute("rel") && link.getAttribute("rel").toLowerCase() == "alternate" && link.hasAttribute("href") && link.hasAttribute("type")) {
                var type = link.type.toLowerCase();
                if (type.indexOf("rss") > -1 || type.indexOf("atom") > -1 || type.indexOf("application/json") > -1) {
                    found = "true";
                    break;
                }
            }
        }

        safari.extension.dispatchMessage(found);
        
    });
})();
